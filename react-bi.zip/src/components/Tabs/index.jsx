import React from "react";
import { Decoration3, BorderBox12 } from "@jiaminghi/data-view-react";
import styles from "./index.module.less";

export default function Tabs() {
  return (
    <div className={styles["tabs-wrap"]}>
      <div className="left">

        <div className="tab-item active">
          <BorderBox12>首页</BorderBox12>
        </div>
        <div className="tab-item">
          <BorderBox12>人力分析</BorderBox12>
        </div>
        <div className="tab-item">
          <BorderBox12>销售分析</BorderBox12>
        </div>
        <div className="tab-item">
          <BorderBox12>毛利分析</BorderBox12>
        </div>
      </div>
      <div className="right">
        <div className="tab-item">
          <BorderBox12>利润分析</BorderBox12>
        </div>
        <div className="tab-item">
          <BorderBox12>推广分析</BorderBox12>
        </div>
        <div className="tab-item">
          <BorderBox12>盈亏测算</BorderBox12>
        </div>
        <div className="tab-item">
          <Decoration3 style={{ width: "100%", height: "100%" }} />
        </div>
      </div>
    </div>
  );
}
