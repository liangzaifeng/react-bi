import React from "react";
import {
  Decoration5,
  Decoration8,
  Decoration10,
} from "@jiaminghi/data-view-react";
import Tabs from "../Tabs";
import styles from "./index.module.less";
export default function Header() {
  return (
    <div className={styles.header}>
      <div className="top">
        <Decoration8
          color={["#6a98ec", "#6a98ec"]}
          style={{ width: "20%", height: "50px" }}
        />
        <div className="title-wrap">
          <h1 className="title">营销中心经营分析看板</h1>
          <Decoration5
            color={["#6a98ec", "#6a98ec"]}
            style={{ width: "100%", height: "120px" }}
          />
        </div>
        <Decoration8
          color={["#6a98ec", "#6a98ec"]}
          reverse={true}
          style={{ width: "20%", height: "50px" }}
        />
      </div>
      <div className="tabs">
        <Tabs />
      </div>
      <Decoration10
        color={["#6a98ec"]}
        style={{ width: "100%", height: "5px" }}
      />
    </div>
  );
}
