import React, { useEffect, useRef } from "react";
import styles from "./index.module.less";
import useResize from '@/hooks/useResize'
const echarts = require("echarts/lib/echarts");
require("echarts/lib/component/grid");
require("echarts/lib/chart/line");
export default function A() {
  const refDom = useRef(null);
  const myChart = useRef(null);
  useResize(myChart)
  var option;

  option = {
    xAxis: {
      type: "category",
      data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    },
    yAxis: {
      type: "value",
    },
    series: [
      {
        data: [820, 932, 901, 934, 1290, 1330, 1320],
        type: "line",
        smooth: true,
      },
    ],
  };

 useEffect(() => {
   window.addEventListener("load", () => {
     myChart.current = echarts.init(refDom.current);
     option && myChart.current.setOption(option);
   });
 }, [option, refDom]);


  

  return (
    <div ref={refDom} className={styles["div-a"]}>
      A
    </div>
  );
}
